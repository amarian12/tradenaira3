CKEDITOR.editorConfig = function( config ) {
  // Define changes to default configuration here.
  // For the complete reference:
  // http://docs.ckeditor.com/#!/api/CKEDITOR.config

  // The toolbar groups arrangement, optimized for two toolbar rows.
  config.toolbarGroups = [
    { name: 'styles' },
    { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
    { name: 'links' },
    { name: 'insert' },
    { name: 'forms' },
    { name: 'others' },
    { name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ] },
    { name: 'colors' },
    { name: 'editing',     groups: [ 'find', 'selection', 'spellchecker' ] },
    { name: 'document',    groups: [ 'mode', 'document', 'doctools' ] },
    { name: 'tools' },
  ];

  // Remove some buttons, provided by the standard plugins, which we don't
  // need to have in the Standard(s) toolbar.
  config.removeButtons = 'Underline,Subscript,Superscript';

  // Se the most common block elements.
  config.format_tags = 'p;h1;h2;h3;pre';

  // Make dialogs simpler.
  config.removeDialogTabs = 'image:advanced;link:advanced';

  // "Read more" plugin
  config.extraPlugins = 'wpmore';

  // URL to upload images with image plugin
  config.filebrowserUploadUrl = '/blog/admin/images';

  // Height
  config.height = '350px';
};


